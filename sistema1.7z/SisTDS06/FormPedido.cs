﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisTDS06
{
    public partial class FormPedido : Form
    {
       
        private void AutoCompleteCliente()
        {
            Pedido lista = new Pedido();
            var source = new AutoCompleteStringCollection();

            txtCliente.AutoCompleteCustomSource = source;
            txtCliente.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtCliente.AutoCompleteSource = AutoCompleteSource.CustomSource;

            foreach (var nome in lista.listaPedidoCliente())
            {
                source.Add(nome);
            }

        }

        private void AutoCompleteProduto()
        {
            Pedido lista = new Pedido();
            var src = new AutoCompleteStringCollection();

            txtProduto.AutoCompleteCustomSource = src;
            txtProduto.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtProduto.AutoCompleteSource = AutoCompleteSource.CustomSource;

            foreach (var nome in lista.listaPedidoProduto())
            {
                src.Add(nome);
            }

        }



        public FormPedido()
        {
           
            InitializeComponent();
            AutoCompleteCliente();
            AutoCompleteProduto();
        }

        private void FormPedido_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPedido_Click(object sender, EventArgs e)
        {

            DateTime data = DateTime.Now;
            string dta = data.ToString("yyyy/MM/dd");
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO pedido(cpf_cliente,valot_total, data_pedido) VALUES ('','','"+dta+"')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
            MessageBox.Show("Pedido Emitido com sucesso, adicione os itens");
            txtId.Enabled = true;
            txtCliente.Enabled = true;
            txtProduto.Enabled = true;
            txtQuant.Enabled = true;
            txtUnit.Enabled = true;

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Pedido adicionar = new Pedido();
            adicionar.Inserir_Item(txtProduto.Text,Convert.ToInt32(txtQuant.Text),Convert.ToDouble(txtUnit.Text));


        }
    }
}
