﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisTDS06
{
    class Pedido
    {

        public string nome_cliente { get; set; }
        public string nome_produto { get; set; }

        public int id_item { get; set; }
        public int id_pedido { get; set; }
        public int id_produto { get; set; }
        public int quantidade { get; set; }
        public double preco { get; set; }
        public double total { get; set; }
        public int codigo { get; set; }
        public DateTime dt_pedido { get; set; }
        public string cpf { get; set; }



        public void Inserir_Item(string produto, int quantidade, double preco)
        {

            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM produto WHERE nome='"+ produto +"'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                codigo = Convert.ToInt32(dr["Id"]);

            }
            dr.Close();
            try
            {
                DateTime hoje = DateTime.Now;
                string dta = hoje.ToString("yyyy/MM/dd");
                double total = quantidade * preco;
                cmd.CommandText = "INSERT INTO itens_pedido(dt_pedido, id_produto, quantidade, preco, total) VALUES ('" + dta + "','" + codigo + "','" + quantidade + "','" + preco + "','" + total + "')";
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                ClassConecta.FecharConexao();
                MessageBox.Show("Item adicionado com sucesso!");
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        public void editarItem(int id, int quantidade, double preco)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM itens_pedido WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                codigo = Convert.ToInt32(dr["id_produto"]);

            }
            dr.Close();
            try
            {
                DateTime hoje = DateTime.Now;
                string dta = hoje.ToString("yyyy/MM/dd");
                double total = quantidade * preco;
                cmd.CommandText = "UPDATE itens_pedido SET dt_pedido='" + dta + "',id_produto=" + codigo + ",quantidade='" + quantidade + "',preco='" + preco + "',total='" + total + "' WHERE Id = '" + id + "'";
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                ClassConecta.FecharConexao();
                MessageBox.Show("Item atualizado com sucesso!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        public void venda(string nome)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM itens_pedido";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                total += Convert.ToDouble(dr["total"]);

            }
            dr.Close();

            cmd.CommandText = "SELECT * FROM cliente WHERE nome='"+nome.Trim()+"'";
            cmd.CommandType = CommandType.Text;
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cpf = dr["cpf"].ToString();

            }
            dr.Close();

            try
            {
                DateTime hoje = DateTime.Now;
                string dta = hoje.ToString("yyyy/MM/dd");
                double total = quantidade * preco;
                cmd.CommandText = "INSERT INTO pedido(cpf_cliente, valot_total, data_pedido) VALUES ('"+ cpf +"','"+total+ "','"+dta+ "')";
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                ClassConecta.FecharConexao();
                MessageBox.Show("Item atualizado com sucesso!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        public List<Pedido> itensPedido()
        {
            List<Pedido> pedidos = new List<Pedido>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM itens_pedido";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            
            while (dr.Read())
            {
                Pedido p = new Pedido();
                p.id_item = Convert.ToInt32(dr["Id"]);
                p.dt_pedido = Convert.ToDateTime(dr["dt_pedido"]);
                p.id_produto = Convert.ToInt32(dr["id_produto"]);
                p.quantidade = Convert.ToInt32(dr["quantidade"]);
                p.preco = Convert.ToDouble(dr["preco"]);
                p.total = Convert.ToDouble(dr["total"]);
                pedidos.Add(p);

            }

            return pedidos;
        }

        public List<String> listaPedidoCliente()
        {
            List<String> cliente = new List<String>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM cliente";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pedido p = new Pedido();
                p.nome_cliente = dr["nome"].ToString();

                cliente.Add(p.nome_cliente.Trim());
                
            }
            dr.Close();
            return cliente;
        }

        public List<String> listaPedidoProduto()
        {
            List<String> produto = new List<String>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM produto";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pedido p = new Pedido();
                p.nome_produto = dr["nome"].ToString();

                produto.Add(p.nome_produto.Trim());

            }
            dr.Close();
            return produto;
        }

        public void localizarItem(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM itens_pedido WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                id_item = Convert.ToInt32(dr["Id"]);
                dt_pedido = Convert.ToDateTime(dr["dt_pedido"]);
                id_produto = Convert.ToInt32(dr["id_produto"]);
                quantidade = Convert.ToInt32(dr["quantidade"]);
                preco = Convert.ToDouble(dr["preco"]);
                total = Convert.ToDouble(dr["total"]);

            }

            dr.Close();
            cmd.CommandText = "SELECT * FROM produto WHERE Id='" + id_produto + "'";
            cmd.CommandType = CommandType.Text;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome_produto = dr["nome"].ToString();


            }

        }



    }  
}
