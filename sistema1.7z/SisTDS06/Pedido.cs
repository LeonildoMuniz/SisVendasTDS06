﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisTDS06
{
    class Pedido
    {

        public string nome_cliente { get; set; }
        public string nome_produto { get; set; }
        public int id_pr { get; set; }

        public int id_pedido { get; set; }
        public int id_produto { get; set; }
        public int quantidade { get; set; }
        public double preco { get; set; }
        public double total { get; set; }

        public int codigo { get; set; }


        public void Inserir_Item(string produto, int quantidade, double preco)
        {

            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM produto WHERE nome='"+ produto +"'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                codigo = Convert.ToInt32(dr["Id"]);

            }
            dr.Close();
            try
            {
                DateTime hoje = DateTime.Now;
                string dta = hoje.ToString("yyyy/MM/dd");
                double total = quantidade * preco;
                cmd.CommandText = "INSERT INTO itens_pedido(dt_pedido, id_produto, quantidade, preco, total) VALUES ('" + dta + "','" + codigo + "','" + quantidade + "','" + preco + "','" + total + "')";
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                ClassConecta.FecharConexao();
                MessageBox.Show("Item adicionado com sucesso!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        public List<String> listaPedidoCliente()
        {
            List<String> cliente = new List<String>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM cliente";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pedido p = new Pedido();
                p.nome_cliente = dr["nome"].ToString();

                cliente.Add(p.nome_cliente.Trim());
                
            }
            dr.Close();
            return cliente;
        }

        public List<String> listaPedidoProduto()
        {
            List<String> produto = new List<String>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM produto";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pedido p = new Pedido();
                p.nome_produto = dr["nome"].ToString();

                produto.Add(p.nome_produto.Trim());

            }
            dr.Close();
            return produto;
        }

    }  
}
