﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SisTDS06
{
    class Pedido
    {
        public int id_pedido { get; set; }
        public string cpf { get; set; }
        public double valor_pedido { get; set; }
        public DateTime data_pedido { get; set; }
        public string nome_cliente { get; set; }

        public int id_itens { get; set; }
        public int quant_item { get; set; }
        public double preco_item { get; set; }
        public double total_item { get; set; }



        public List<string> listaPedidoCliente()
        {
            List<string> cliente = new List<string>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM cliente";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pedido p = new Pedido();
                p.nome_cliente = dr["nome"].ToString();

                cliente.Add(p);
            }
            return cliente;

        }



    }
}
