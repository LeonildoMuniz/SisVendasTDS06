﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisTDS06
{
    public partial class FormPedido : Form
    {
       
        private void AutoComplete()
        {
            Pedido lista = new Pedido();
            lista.listaPedidoCliente();
            var source = new AutoCompleteStringCollection();

            source.Add(); 
            txtCliente.AutoCompleteCustomSource = source;
            txtCliente.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtCliente.AutoCompleteSource = AutoCompleteSource.CustomSource;

        }

        public FormPedido()
        {
           
            InitializeComponent();
            AutoComplete();
        }

        private void FormPedido_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
